const axios = require("axios");

// Konfigurasi API TurboSeek
const BASE_URL = "https://www.turboseek.io/api";
const HEADERS = {
  "Content-Type": "application/json",
  "Accept": "application/json, text/plain, */*",
  "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Mobile Safari/537.36",
  "Origin": "https://www.turboseek.io",
  "Referer": "https://www.turboseek.io/"
};

// Ambil sumber jawaban
async function source(query) {
  try {
    const { data } = await axios.post(`${BASE_URL}/getSources`, { question: query }, { headers: HEADERS, timeout: 15000 });
    return data || [];
  } catch (err) {
    console.error("Error source:", err.message);
    return [];
  }
}

// Ambil jawaban lengkap
async function answer(query, sources) {
  try {
    const { data } = await axios.post(`${BASE_URL}/getAnswer`, { question: query, sources }, { headers: HEADERS, timeout: 20000 });
    return data || "";
  } catch (err) {
    console.error("Error answer:", err.message);
    return "";
  }
}

// Fungsi utama siap dipakai
async function turboseek(query) {
  try {
    const sources = await source(query);
    if (!sources || sources.length === 0) {
      return { sukses: false, pesan: "❌ Tidak menemukan sumber informasi" };
    }

    const rawJawab = await answer(query, sources);
    const teksBersih = String(rawJawab).replace(/<[^>]*>/g, "").replace(/\s+/g, " ").trim();

    return {
      sukses: true,
      pertanyaan: query,
      jawaban: teksBersih,
      sumber: sources.map(s => ({ judul: s.title, url: s.url }))
    };
  } catch (err) {
    return { sukses: false, pesan: "❌ Kesalahan: " + err.message };
  }
}

// Contoh pakai langsung
// turboseek("Apa itu HTML?").then(res => console.log(res));

// Ekspor supaya bisa dipakai di file lain
module.exports = { turboseek };
